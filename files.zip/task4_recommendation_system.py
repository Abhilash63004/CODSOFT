"""
CODSOFT AI Internship - Task 4
Simple Recommendation System
Supports:
  • Collaborative Filtering (user-based)
  • Content-Based Filtering (genre similarity)
"""

import math
from collections import defaultdict

# ── Sample dataset ────────────────────────────────────────────────────────────
# ratings[user][movie] = score (1-5)
RATINGS = {
    "Alice": {"Inception": 5, "Interstellar": 4, "The Matrix": 5, "Avatar": 3, "Titanic": 2},
    "Bob":   {"Inception": 4, "Interstellar": 5, "The Matrix": 4, "Avengers": 3, "Titanic": 1},
    "Carol": {"Avatar": 5, "Titanic": 4, "The Notebook": 5, "La La Land": 4},
    "Dave":  {"The Matrix": 3, "Avengers": 5, "Inception": 2, "Spider-Man": 5, "Iron Man": 4},
    "Eve":   {"Titanic": 5, "La La Land": 5, "The Notebook": 4, "Avatar": 4, "Interstellar": 2},
    "Frank": {"Avengers": 4, "Spider-Man": 4, "Iron Man": 5, "The Matrix": 3, "Inception": 3},
}

# genres[movie] = list of genres
GENRES = {
    "Inception":     ["Sci-Fi", "Thriller", "Action"],
    "Interstellar":  ["Sci-Fi", "Drama", "Adventure"],
    "The Matrix":    ["Sci-Fi", "Action", "Thriller"],
    "Avatar":        ["Sci-Fi", "Adventure", "Action"],
    "Titanic":       ["Drama", "Romance"],
    "The Notebook":  ["Drama", "Romance"],
    "La La Land":    ["Drama", "Romance", "Musical"],
    "Avengers":      ["Action", "Sci-Fi", "Adventure"],
    "Spider-Man":    ["Action", "Adventure"],
    "Iron Man":      ["Action", "Sci-Fi"],
}


# ── Collaborative Filtering ───────────────────────────────────────────────────
def cosine_similarity(u1, u2):
    """Cosine similarity between two users' rating dicts."""
    common = set(u1) & set(u2)
    if not common:
        return 0.0
    dot   = sum(u1[m] * u2[m] for m in common)
    norm1 = math.sqrt(sum(v**2 for v in u1.values()))
    norm2 = math.sqrt(sum(v**2 for v in u2.values()))
    return dot / (norm1 * norm2) if norm1 and norm2 else 0.0


def collaborative_recommend(target_user, top_n=5):
    target_ratings = RATINGS[target_user]
    seen = set(target_ratings)

    # Compute similarity with every other user
    sims = {}
    for user, ratings in RATINGS.items():
        if user != target_user:
            sims[user] = cosine_similarity(target_ratings, ratings)

    # Weighted score for unseen movies
    scores = defaultdict(float)
    sim_sum = defaultdict(float)
    for user, sim in sims.items():
        if sim <= 0:
            continue
        for movie, rating in RATINGS[user].items():
            if movie not in seen:
                scores[movie]  += sim * rating
                sim_sum[movie] += sim

    weighted = {m: scores[m] / sim_sum[m] for m in scores}
    ranked = sorted(weighted, key=weighted.get, reverse=True)[:top_n]
    return [(m, round(weighted[m], 2)) for m in ranked]


# ── Content-Based Filtering ───────────────────────────────────────────────────
def jaccard_similarity(g1, g2):
    s1, s2 = set(g1), set(g2)
    if not s1 or not s2:
        return 0.0
    return len(s1 & s2) / len(s1 | s2)


def content_based_recommend(target_user, top_n=5):
    liked = [m for m, r in RATINGS[target_user].items() if r >= 4]
    seen  = set(RATINGS[target_user])

    scores = defaultdict(float)
    for candidate, cg in GENRES.items():
        if candidate in seen:
            continue
        sims = [jaccard_similarity(GENRES.get(l, []), cg) for l in liked if l in GENRES]
        if sims:
            scores[candidate] = sum(sims) / len(sims)

    ranked = sorted(scores, key=scores.get, reverse=True)[:top_n]
    return [(m, round(scores[m], 2)) for m in ranked]


# ── CLI ───────────────────────────────────────────────────────────────────────
def display_recommendations(title, recs):
    print(f"\n{'─'*40}")
    print(f"  {title}")
    print(f"{'─'*40}")
    if not recs:
        print("  No recommendations found.")
    for i, (movie, score) in enumerate(recs, 1):
        print(f"  {i}. {movie:<20} (score: {score})")


def main():
    print("=" * 45)
    print("  CODSOFT Recommendation System – Task 4")
    print("=" * 45)
    print("\nAvailable users:", ", ".join(RATINGS.keys()))

    while True:
        user = input("\nEnter your username (or 'quit' to exit): ").strip()
        if user.lower() == "quit":
            print("Goodbye! 👋")
            break
        if user not in RATINGS:
            print(f"User '{user}' not found. Please try again.")
            continue

        print(f"\nHello, {user}! Here are your personalised movie recommendations:\n")

        cf_recs  = collaborative_recommend(user)
        cb_recs  = content_based_recommend(user)

        display_recommendations("🤝 Collaborative Filtering (users like you)", cf_recs)
        display_recommendations("🎬 Content-Based Filtering (genre similarity)", cb_recs)

        print(f"\n  Your rated movies:")
        for movie, rating in sorted(RATINGS[user].items(), key=lambda x: -x[1]):
            print(f"    {'⭐'*rating} {movie} ({rating}/5)")


if __name__ == "__main__":
    main()
