"""
CODSOFT AI Internship - Task 2
Tic-Tac-Toe AI using Minimax with Alpha-Beta Pruning
"""

import math

# ── Board helpers ────────────────────────────────────────────────────────────
def create_board():
    return [" "] * 9          # indices 0-8, row-major

def print_board(board):
    r = board
    print(f"\n {r[0]} | {r[1]} | {r[2]}")
    print("---+---+---")
    print(f" {r[3]} | {r[4]} | {r[5]}")
    print("---+---+---")
    print(f" {r[6]} | {r[7]} | {r[8]}\n")

WINNING_LINES = [
    (0,1,2),(3,4,5),(6,7,8),   # rows
    (0,3,6),(1,4,7),(2,5,8),   # cols
    (0,4,8),(2,4,6),            # diagonals
]

def winner(board, player):
    return any(board[a]==board[b]==board[c]==player for a,b,c in WINNING_LINES)

def is_draw(board):
    return " " not in board

def available_moves(board):
    return [i for i, v in enumerate(board) if v == " "]


# ── Minimax with Alpha-Beta Pruning ──────────────────────────────────────────
def minimax(board, is_maximizing, alpha, beta):
    if winner(board, "X"):   return 10
    if winner(board, "O"):   return -10
    if is_draw(board):        return 0

    if is_maximizing:                          # AI (X) maximises
        best = -math.inf
        for move in available_moves(board):
            board[move] = "X"
            score = minimax(board, False, alpha, beta)
            board[move] = " "
            best = max(best, score)
            alpha = max(alpha, best)
            if beta <= alpha:
                break                          # beta cut-off
        return best
    else:                                      # Human (O) minimises
        best = math.inf
        for move in available_moves(board):
            board[move] = "O"
            score = minimax(board, True, alpha, beta)
            board[move] = " "
            best = min(best, score)
            beta = min(beta, best)
            if beta <= alpha:
                break                          # alpha cut-off
        return best


def best_move(board):
    best_val, best_pos = -math.inf, -1
    for move in available_moves(board):
        board[move] = "X"
        val = minimax(board, False, -math.inf, math.inf)
        board[move] = " "
        if val > best_val:
            best_val, best_pos = val, move
    return best_pos


# ── Game loop ─────────────────────────────────────────────────────────────────
def get_human_move(board):
    while True:
        try:
            pos = int(input("Enter position (1-9): ")) - 1
            if 0 <= pos <= 8 and board[pos] == " ":
                return pos
            print("Invalid move. Try again.")
        except ValueError:
            print("Please enter a number between 1 and 9.")


def play():
    print("=" * 40)
    print("  CODSOFT Tic-Tac-Toe AI – Task 2")
    print("  You = O  |  AI = X")
    print("  Board positions:")
    print("   1 | 2 | 3")
    print("  ---+---+---")
    print("   4 | 5 | 6")
    print("  ---+---+---")
    print("   7 | 8 | 9")
    print("=" * 40)

    board = create_board()
    human_first = input("\nDo you want to go first? (y/n): ").strip().lower() == "y"
    human_turn = human_first

    while True:
        print_board(board)

        if human_turn:
            print("Your turn (O):")
            move = get_human_move(board)
            board[move] = "O"
            if winner(board, "O"):
                print_board(board)
                print("🎉 You won! (Impressive!)")
                break
        else:
            print("AI is thinking...")
            move = best_move(board)
            board[move] = "X"
            print(f"AI plays position {move + 1}.")
            if winner(board, "X"):
                print_board(board)
                print("🤖 AI wins! Better luck next time.")
                break

        if is_draw(board):
            print_board(board)
            print("🤝 It's a draw!")
            break

        human_turn = not human_turn

    again = input("\nPlay again? (y/n): ").strip().lower()
    if again == "y":
        play()
    else:
        print("Thanks for playing! 👋")


if __name__ == "__main__":
    play()
