"""
CODSOFT AI Internship - Task 1
Rule-Based Chatbot
"""

import re

# ── Knowledge base ──────────────────────────────────────────────────────────
RULES = [
    # Greetings
    (r"\b(hi|hello|hey|howdy|hola)\b",
     "Hello! 👋 I'm a rule-based chatbot. How can I help you today?"),

    # Farewells
    (r"\b(bye|goodbye|see you|exit|quit)\b",
     "Goodbye! Have a great day! 😊"),

    # How are you
    (r"how are you|how('re| are) you doing|what'?s up",
     "I'm just a program, but I'm doing great! Thanks for asking. 😄"),

    # Name
    (r"what('?s| is) your name|who are you",
     "I'm ChatBot, a simple rule-based AI built for the CODSOFT internship!"),

    # Creator
    (r"who (made|created|built) you",
     "I was created as part of the CODSOFT AI Internship – Task 1."),

    # Help
    (r"\bhelp\b|what can you do",
     "I can answer basic questions about myself, tell jokes, share the time, and chat with you!"),

    # Time
    (r"\b(time|clock)\b",
     lambda: f"The current time is {__import__('datetime').datetime.now().strftime('%H:%M:%S')}."),

    # Date
    (r"\b(date|today|day)\b",
     lambda: f"Today is {__import__('datetime').datetime.now().strftime('%A, %d %B %Y')}."),

    # Joke
    (r"\b(joke|funny|laugh)\b",
     "Why don't scientists trust atoms? Because they make up everything! 😂"),

    # Age
    (r"how old are you|your age",
     "I was just born today — every run is my birthday! 🎂"),

    # Weather (static)
    (r"\bweather\b",
     "I can't fetch live weather, but I hope it's sunny wherever you are! ☀️"),

    # Thanks
    (r"\b(thanks|thank you|thx|ty)\b",
     "You're welcome! 😊 Is there anything else I can help you with?"),

    # AI / ML questions
    (r"\b(ai|artificial intelligence|machine learning|ml)\b",
     "AI is a fascinating field! It enables machines to learn and make decisions. Are you studying it?"),

    # Python
    (r"\bpython\b",
     "Python is a great language for AI! Simple syntax, powerful libraries like NumPy, Pandas, and TensorFlow."),

    # Default fallback
    (r".*",
     "Hmm, I'm not sure about that. Try asking something else or type 'help' to see what I can do!"),
]


def get_response(user_input: str) -> str:
    text = user_input.lower().strip()
    for pattern, response in RULES:
        if re.search(pattern, text):
            return response() if callable(response) else response
    return "I didn't understand that. Type 'help' for options."


def main():
    print("=" * 50)
    print("       CODSOFT AI Chatbot – Task 1")
    print("  Type 'bye' or 'quit' to exit the chat.")
    print("=" * 50)

    while True:
        try:
            user_input = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nChatBot: Goodbye! 👋")
            break

        if not user_input:
            continue

        response = get_response(user_input)
        print(f"ChatBot: {response}")

        if re.search(r"\b(bye|goodbye|exit|quit)\b", user_input.lower()):
            break


if __name__ == "__main__":
    main()
