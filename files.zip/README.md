# CODSOFT – Artificial Intelligence Internship

This repository contains the completed tasks for the **CodSoft AI Internship**.

---

## ✅ Task 1 – Rule-Based Chatbot
**File:** `task1_chatbot.py`

A conversational chatbot that uses regex pattern matching to identify user intent and respond with predefined replies. Handles greetings, farewells, jokes, time/date queries, and more.

**Run:**
```bash
python task1_chatbot.py
```

---

## ✅ Task 2 – Tic-Tac-Toe AI
**File:** `task2_tictactoe_ai.py`

An unbeatable Tic-Tac-Toe AI built using the **Minimax algorithm with Alpha-Beta Pruning**. The AI always plays optimally — the best outcome a human can achieve is a draw.

**Run:**
```bash
python task2_tictactoe_ai.py
```

---

## ✅ Task 4 – Recommendation System
**File:** `task4_recommendation_system.py`

A movie recommendation system implementing two classic techniques:
- **Collaborative Filtering** – recommends movies based on what similar users liked (cosine similarity)
- **Content-Based Filtering** – recommends movies based on genre similarity to movies you already rated highly (Jaccard similarity)

No external libraries required — built with pure Python.

**Run:**
```bash
python task4_recommendation_system.py
```

---

## Requirements
- Python 3.7+
- No third-party libraries needed (pure Python standard library only)

---

## Author
CodSoft AI Internship Participant  
`#codsoft #internship #artificialintelligence`
